/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ROSERO
 */
public class Operador {
    static Conexion con;
    static String[] res= new String[3], bill,consulta;
    
    static String nombre,email,id;
    
    public Operador(Conexion conn,String user){
        con  = conn;
        getData(user);
    }
    
    public static void getData(String user){
        try {
            res = con.getUserInfo(user);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }        
        nombre = res[0];
        id = res[1];
        email =  res[2];
    }
    
    public static String[] getBillInfo(String user,String id){
        try {
            bill= new String[con.getInfoBill(user,id).length] ;
            bill=con.getInfoBill(user,id);
            
        } catch (SQLException ex) {
             System.out.println(ex.getMessage());
        }
        /*
        nombre cliente, dir, cc, celular, fecha expediciòn factura,
        n. factura, fecha limite de pago, total a pagar, pago con mora ,
        supongo resumen de pagos
        */
        return bill;
    }
    
    public static String[] consultar(String id){
        try {
            bill= new String[con.consultaOp(id).length] ;
            bill=con.consultaOp(id);
        } catch (SQLException ex) {
             System.out.println(ex.getMessage());
        }
        return consulta;
    } 
}
