/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;

import java.sql.*;
/*
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
*/

/**
 * class that access the database that can get or save 
 * information, given the necessity
 * 
 * @author Juan Camilo Rosero
 */
public class Conexion {
    
    private static final String DRIVER = "org.postgresql.Driver";
    private static final String URL_CONEXION = "jdbc:postgresql://lallah.db.elephantsql.com:5432/ybpavmnk";
    final String usuario = "ybpavmnk";
    final String password = "YqGK6-mo_E5wl9FiJfCtbs_9InpHpgIC";
    /*
    private static final String DRIVER = "org.postgresql.Driver";
    private static final String URL_CONEXION = "jdbc:postgresql://misdvqpxuhusea:ec74866febb09976e0df523e61b2720e2287d026ee5c6550aa3b4ad0d793a07c@ec2-34-237-236-32.compute-1.amazonaws.com:5432/d652pg3qedd9eg";
    final String usuario = "misdvqpxuhusea";
    final String password = "ec74866febb09976e0df523e61b2720e2287d026ee5c6550aa3b4ad0d793a07c";
    */
    Connection dbConnection = null;
    Statement statement = null;
    String usr,pas,rol,nom,id,email;
    String[] res;
    Boolean bandera;
    
    /**
     * search in the database and returns the password of a given user name
     * @param user name of the user who we are searching the password of
     * @return the value of the password of the user
     * @throws SQLException 
     */
    public  String getLogin(String user) throws SQLException {
        
        
        try {
            Class.forName(DRIVER);
            dbConnection = DriverManager.getConnection(URL_CONEXION, usuario, password);
            String selectTableSQL = "SELECT contrasena FROM usuario Where email='" + user + "'" ;
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(selectTableSQL);
            while (rs.next()) {
                pas = rs.getString("contrasena");
                
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());            
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();         
            }
        }
        return pas;
    }
    
    /**
     * search in the database and returns the rol of a given user name
     * @param user name of the user who we are searching the rol of
     * @return the value of the rol of the user
     * @throws SQLException 
     */
    public String getRol(String user) throws SQLException {
        try {
            Class.forName(DRIVER);
            dbConnection = DriverManager.getConnection(URL_CONEXION, usuario, password);
            String selectTableSQL = "SELECT rol FROM usuario Where email='" + user + "'" ;
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(selectTableSQL);
            while (rs.next()) {
                rol = rs.getString("rol");
                
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());            
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return rol;
    }
    
    /**
     * this method recieves an email and returns the name, id and email of the user that matches the email
     * @param user email for searching the user's information
     * @return array of 3 values, first the name, second, his id, and third, his email
     * @throws SQLException 
     */
     public String[] getUserInfo(String user) throws SQLException {
        try {
            Class.forName(DRIVER);
            dbConnection = DriverManager.getConnection(URL_CONEXION, usuario, password);
            String selectTableSQL = "SELECT nombre,id,email FROM usuario Where email='" + user + "'" ;
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(selectTableSQL);
            while (rs.next()) {
                nom = rs.getString("nombre");
                id = rs.getString("id");
                email = rs.getString("email");
                
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());            
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        res = new String [3];
        res[0]=nom;
        res[1]=id;
        res[2]=email;
        return res;
    }
    
     /**
      * 
      * @param user name of the client one needs to search
      * @param identification id of the client
      * @return
      * @throws SQLException 
      */
    public String[] getInfoBill(String user,String identification) throws SQLException {
       try {
            Class.forName(DRIVER);
            dbConnection = DriverManager.getConnection(URL_CONEXION, usuario, password);
            String selectTableSQL = "SELECT nombre,id,email FROM usuario Where email='" + user + "'" ;
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(selectTableSQL);
            while (rs.next()) {
                nom = rs.getString("nombre");
                id = rs.getString("id");
                email = rs.getString("email");
                
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());            
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        res = new String [3];
        res[0]=nom;
        res[1]=id;
        res[2]=email;
        return res;
    }

     public String[] consultaOp(String identification) throws SQLException {
       try {
            Class.forName(DRIVER);
            dbConnection = DriverManager.getConnection(URL_CONEXION, usuario, password);
            String selectTableSQL = "SELECT nombre,id,email FROM usuario Where email='" + identification + "'" ;
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(selectTableSQL);
            while (rs.next()) {
                nom = rs.getString("nombre");
                id = rs.getString("id");
                email = rs.getString("email");
                
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());            
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        res = new String [3];
        res[0]=nom;
        res[1]=id;
        res[2]=email;
        return res;
    }
     
    public boolean insertAdmin(String[] args) throws SQLException {
        try {
            Class.forName(DRIVER);
            dbConnection = DriverManager.getConnection(URL_CONEXION, usuario, password);
            String insertTableSQL = "INSERT INTO usuario (id,nombre,edad,direccion,telefono,email,contrasena,rol) VALUES ('"+args[1]+"','"+args[2]+"','"+args[3]+"','"+args[4]+"','"+args[5]+
                                                 "','"+args[6]+"','"+args[7]+"','"+args[8]+"');" ; 
            statement = dbConnection.createStatement();
            int rs = statement.executeUpdate(insertTableSQL);
            if (rs==0){
                bandera=true;
            }else
                bandera=false;
        } catch (SQLException e) {
            System.out.println(e.getMessage());            
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return bandera;
    }
}