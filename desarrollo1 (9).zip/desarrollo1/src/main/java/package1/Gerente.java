/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *  Class defining the functionalities of the Admin dashboard
 * @author Juan Camilo Rosero
 */
public class Gerente {
    
    
    static Conexion con;
    static String[] res= new String[3],pagosA,estadisticas,consumo;
    static String nombre,email,id;
    static boolean bandera;
    
    public Gerente(Conexion conn,String user){
        con = conn;
        getData(user);
    }
    
    public static void getData(String user){
        try {
            res = con.getUserInfo(user);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        nombre = res[0];
        id = res[1];
        email =  res[2];
    }
    
    public static void getPagosAño(){
        try {
            pagosA = con.getPagoAnual();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
    public static void getEstadisticasMes(){
        try {
            estadisticas = con.getEstadisticasMes();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
    public static void getConsumo(){
        try {
            consumo = con.getConsumo();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
}
