/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *  Class defining the functionalities of the Admin dashboard
 * @author Juan Camilo Rosero
 */
public class Operador {
    static Conexion con;
    static String[] res= new String[3], bill,consulta;
    static boolean bandera;
    static String nombre,email,id,totalPago;
    
    
    public Operador(Conexion conn,String user){
        con  = conn;
        getData(user);
    }
    
    public static void getData(String user){
        try {
            res = con.getUserInfo(user);
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }        
        nombre = res[0];
        id = res[1];
        email =  res[2];
    }
    
    public static boolean insertPago(String[] args){
        try {
            if(con.insertAdmin(args)){
                bandera= true;
            }else
                bandera= false;
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return bandera;
    }
    
    
    public static void getBillInfo(String args){
        try {
            bill= new String[14];
            bill=con.getInfoBill(args);
            double aux1= Double.parseDouble(bill[13])+Double.parseDouble(bill[7]);
            String aux2= Double.toString(aux1);
            totalPago= aux2;
            
        } catch (SQLException ex) {
             System.out.println(ex.getMessage());
        }
        /*
        numerocuenta,fechainscripcion,activo,zona,tipocliente,fechacorte,fechaoportuna,mora,cedula,direccion,nombre,mesfactura,kwh,valordeuda
        */
    
    }
    
    public static void consultaOp(String args){
        try {
            consulta= new String[con.consultaOp(args).length] ;
            consulta=con.consultaOp(args);
            
        } catch (SQLException ex) {
             System.out.println(ex.getMessage());
        }
    } 
}
