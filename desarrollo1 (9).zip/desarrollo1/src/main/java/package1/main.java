/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;

import java.sql.*;
/**
 *
 * @author ROSERO
 */
public class  main{
	
	public static void main(String[] args) {
            
                Conexion con = new Conexion();
                String val1,val2,val3,val4;
                boolean val5;
                val1="juan.camilo.rosero@correounivalle.edu.co";
                val2="Juan0620";
                val3= "";
                val4= new String();
                try {
                    val3=con.getLogin(val1);
                    if (val2.equals(val3)){
                        val4=con.getRol(val1);
                        System.out.print(val4);
                    }else{
                    System.out.print(val3);
                    }
                } catch (SQLException ex) {
                    System.out.println(ex.getMessage()); 
                    
                }
                            
                
        }
        

}


