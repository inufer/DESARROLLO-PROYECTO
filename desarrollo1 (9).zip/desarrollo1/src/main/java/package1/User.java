/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * class for the validation of the user in the login panel and to help
 * assing a rol if a sucessfull login happens
 * @author Juan Camilo Rosero
 */
public class User{
    static Conexion con;
    static String rol,passuser;
    static boolean bandera;
    public User(Conexion conect){
        con = conect;
    }
    /**
     * returns the rol of a given user
     * @param user given user name
     * @return value of the rol pertaining the given user
     */
    public static String returnRol (String user){
        
        try {
           rol = con.getRol(user);
           
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return rol;
    }
    
    /**
     * validate the password given when login in with a valid user
     * @param user is the given user name
     * @param pass is the password the is going to be validated
     * @return true if the password is valid, false otherwise
     */
    public static boolean valLogin(String user, String pass){
        try {
            passuser = con.getLogin(user);
            bandera = passuser.equals(pass);
       
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return bandera;
    }
}

