/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package package1;

import java.sql.*;
/*
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
*/

/**
 * class that access the database that can get or save 
 * information, given the necessity
 * 
 * @author Juan Camilo Rosero
 */
public class Conexion {
    
    private static final String DRIVER = "org.postgresql.Driver";
    private static final String URL_CONEXION = "jdbc:postgresql://lallah.db.elephantsql.com:5432/ybpavmnk";
    final String usuario = "ybpavmnk";
    final String password = "YqGK6-mo_E5wl9FiJfCtbs_9InpHpgIC";
    Connection dbConnection = null;
    Statement statement = null;
    String usr,pas,rol,nom,id,email,lastPago;
    int idpago;
    String[] res,pagoA,estadisticas,consumo;
    Boolean bandera;
    
    /*Variables de código SQL para las consultas de pagoAnnual, estadisticas mes y consumo*/
    String pagosAnual = "SELECT date_part('year', Pago.fechaPago) as año, "
                + "sum(Pago.valor) as total_año "
            + "FROM Pago GROUP BY date_part('year', Pago.fechaPago) "
            + "ORDER BY date_part('year', Pago.fechaPago) ASC";
    String clientesMes = "SELECT date_part('year', Cliente.fechaInscripcion) as año,"
                + "date_part('month', Cliente.fechaInscripcion) as mes, count(id) as clientes_mes "
            + "FROM Cliente "
            + "GROUP BY date_part('year', Cliente.fechaInscripcion), "
                + "date_part('month', Cliente.fechaInscripcion) "
            + "ORDER BY date_part('year', Cliente.fechaInscripcion), "
                + "date_part('month', Cliente.fechaInscripcion)";
    String consumoMes = "SELECT date_part('year', DMensual.fechaDeuda) as año, "
                + "date_part('month', DMensual.fechaDeuda) as mes, "
                + "sum(kwh) as kwh_mes "
            + "FROM DMensual "
            + "GROUP BY date_part('year', DMensual.fechaDeuda), "
                + "date_part('month', DMensual.fechaDeuda) "
            + "ORDER BY date_part('year', DMensual.fechaDeuda), "
                + "date_part('month', DMensual.fechaDeuda)";
    
    /*Fin de Código SQL*/
    /*Contador de Filas para las tres consultas anteriores*/
    
    public int pagosAnualCount = 0;
    public int clientesMesCount = 0;
    public int consumoMesCount = 0;
    
    /*Fin de contadores*/
    
    /**
     * search in the database and returns the password of a given user name
     * @param user name of the user who we are searching the password of
     * @return the value of the password of the user
     * @throws SQLException 
     */
    public  String getLogin(String user) throws SQLException {
        
        
        try {
            Class.forName(DRIVER);
            dbConnection = DriverManager.getConnection(URL_CONEXION, usuario, password);
            String selectTableSQL = "SELECT contrasena FROM usuario Where email='" + user + "'" ;
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(selectTableSQL);
            while (rs.next()) {
                pas = rs.getString("contrasena");
                
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());            
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();         
            }
        }
        return pas;
    }
    
    /**
     * search in the database and returns the rol of a given user name
     * @param user name of the user who we are searching the rol of
     * @return the value of the rol of the user
     * @throws SQLException 
     */
    public String getRol(String user) throws SQLException {
        try {
            Class.forName(DRIVER);
            dbConnection = DriverManager.getConnection(URL_CONEXION, usuario, password);
            String selectTableSQL = "SELECT rol FROM usuario Where email='" + user + "'" ;
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(selectTableSQL);
            while (rs.next()) {
                rol = rs.getString("rol");
                
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());            
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return rol;
    }
    
    /**
     * search in the database and returns the id of the las payment
     * @return id of the last payment
     * @throws SQLException 
     */
    public String getLastPago() throws SQLException {
        try {
            Class.forName(DRIVER);
            dbConnection = DriverManager.getConnection(URL_CONEXION, usuario, password);
            String selectTableSQL = "SELECT id FROM usuario ORDER BY ID ASC limit 1" ;
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(selectTableSQL);
            while (rs.next()) {
                lastPago = rs.getString("id");
                
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());            
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        if(lastPago.equals("null")){
            lastPago="0";
        }
        return lastPago;
    }
    
    /**
     * 
     * @return
     * @throws SQLException 
     */
    public String[] getPagoAnual() throws SQLException {
        try {
            Class.forName(DRIVER);
            dbConnection = DriverManager.getConnection(URL_CONEXION, usuario, password);
            String selectTableSQL = pagosAnual ;
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(selectTableSQL);
            res = new String[2];
            
            while (rs.next()) {
                res[0] = rs.getString(1);
                res[1] = rs.getString(2);
                pagosAnualCount++;
                
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());            
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        
        return res;
    }
    
    /**
     * 
     * @return
     * @throws SQLException 
     */
    public String[] getEstadisticasMes() throws SQLException {
        try {
            Class.forName(DRIVER);
            dbConnection = DriverManager.getConnection(URL_CONEXION, usuario, password);
            String selectTableSQL = clientesMes ;
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(selectTableSQL);
            res = new String[3];
            
            while (rs.next()) {
                res[0] = rs.getString(1);
                res[1] = rs.getString(2);
                res[2] = rs.getString(3);
                clientesMesCount++;
                
                               
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());            
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        if(lastPago.equals("null")){
            lastPago="0";
        }
        return res;
    }
    
    /**
     * 
     * @return
     * @throws SQLException 
     */
    public String[] getConsumo() throws SQLException {
        try {
            Class.forName(DRIVER);
            dbConnection = DriverManager.getConnection(URL_CONEXION, usuario, password);
            String selectTableSQL = consumoMes;
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(selectTableSQL);
            res = new String[3];
            
            while (rs.next()) {
                res[0] = rs.getString(1);
                res[1] = rs.getString(2);
                res[2] = rs.getString(3);
                consumoMesCount++;
                
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());            
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        if(lastPago.equals("null")){
            lastPago="0";
        }
        return res;
    }
    
    
    
    /**
     * this method recieves an email and returns the name, id and email of the user that matches the email
     * @param user email for searching the user's information
     * @return array of 3 values, first the name, second, his id, and third, his email
     * @throws SQLException 
     */
     public String[] getUserInfo(String user) throws SQLException {
        try {
            Class.forName(DRIVER);
            dbConnection = DriverManager.getConnection(URL_CONEXION, usuario, password);
            String selectTableSQL = "SELECT nombre,id,email FROM usuario Where email='" + user + "'" ;
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(selectTableSQL);
            while (rs.next()) {
                nom = rs.getString("nombre");
                id = rs.getString("id");
                email = rs.getString("email");
                
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());            
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        res = new String [3];
        res[0]=nom;
        res[1]=id;
        res[2]=email;
        return res;
    }
    
     /**
      * 
      * @param user name of the client one needs to search
      * @param identification id of the client
      * @return
      * @throws SQLException 
      */
    public String[] getInfoBill(String identification) throws SQLException {
       try {
            Class.forName(DRIVER);
            dbConnection = DriverManager.getConnection(URL_CONEXION, usuario, password);
            String selectTableSQL = "select numerocuenta,fechainscripcion,activo,zona,tipocliente,fechacorte,fechaoportuna,mora,cedula,direccion,nombre,mesfacturado,kwh,valordeuda " +
                                        "from cliente inner join dmensual on cliente.cedula=dmensual.clienteid Where cedula='" + identification + "'" ;
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(selectTableSQL);
            res=new String[14];
            /*
            numerocuenta,fechainscripcion,activo,zona,tipocliente,fechacorte,
            fechaoportuna,mora,cedula,direccion,nombre,mesfacturado,kwh,valordeuda
            */
            while (rs.next()) {
                res[0] = rs.getString("numerocuenta");
                res[1] = rs.getString("fechainscripcion");
                res[2] = rs.getString("activo");
                res[3] = rs.getString("zona");
                res[4] = rs.getString("tipocliente");
                res[5] = rs.getString("fechacorte");
                res[6] = rs.getString("fechaoportuna");
                res[7] = rs.getString("mora");
                res[8] = rs.getString("cedula");
                res[9] = rs.getString("direccion");
                res[10] = rs.getString("nombre");
                res[11] = rs.getString("mesfacturado");
                res[12] = rs.getString("kwh");
                res[13] = rs.getString("valordeuda");
                
                
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());            
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return res;
    }

    /**
     * returns the information of a client stored in the database
     * @param identification
     * @return
     * @throws SQLException 
     */
    public String[] consultaOp(String args) throws SQLException {
       try {
            Class.forName(DRIVER);
            dbConnection = DriverManager.getConnection(URL_CONEXION, usuario, password);
            String selectTableSQL = "SELECT nombre,cedula,direccion,numerocuenta,activo,fechacorte,mora FROM cliente Where cedula='" + args + "'" ;
            statement = dbConnection.createStatement();
            ResultSet rs = statement.executeQuery(selectTableSQL);
            res = new String[7];
            while (rs.next()) {
                res[0] = rs.getString("nombre");
                res[1] = rs.getString("cedula");
                res[2] = rs.getString("direccion");
                res[3] = rs.getString("numerocuenta");
                res[4] = rs.getString("activo");
                res[5] = rs.getString("fechacorte");
                res[6] = rs.getString("mora");
                
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());            
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return res;
    }
     
    /**
     * inserts a new user and returns a confirmation if it was successfull
     * @param args values to insert
     * @return true if successfully inserted, false otherwise
     * @throws SQLException 
     */
    public boolean insertAdmin(String[] args) throws SQLException {
        try {
            Class.forName(DRIVER);
            dbConnection = DriverManager.getConnection(URL_CONEXION, usuario, password);
            String insertTableSQL = "INSERT INTO usuario (id,nombre,edad,direccion,telefono,email,contrasena,rol) VALUES ('"+args[0]+"','"+args[1]+"','"+args[2]+"','"+args[3]+"','"+args[4]+
                                                 "','"+args[5]+"','"+args[6]+"','"+args[7]+"');" ; 
            statement = dbConnection.createStatement();
            int rs = statement.executeUpdate(insertTableSQL);
            if (rs==0){
                bandera=true;
            }else
                bandera=false;
        } catch (SQLException e) {
            System.out.println(e.getMessage());            
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return bandera;
    }
    
     /**
     * inserts a new client and returns a confirmation if it was successfull
     * @param args values to insert
     * @return true if successfully inserted, false otherwise
     * @throws SQLException 
     */
    public boolean insertClient(String[] args) throws SQLException {
        try {
            Class.forName(DRIVER);
            dbConnection = DriverManager.getConnection(URL_CONEXION, usuario, password);
            String insertTableSQL = "INSERT INTO cliente (id,numerocuenta,fechainscripcion,activo,zona,tipocliente,fechacorte,fechaoportuna,mora,cedula,direccion,nombre) VALUES ('"+args[0]+"','"+args[1]+"','"+args[2]+"','"+args[3]+"','"+args[4]+
                                                 "','"+args[5]+"','"+args[6]+"','"+args[7]+"','"+args[8]+"','"+args[9]+"','"+"','"+args[10]+"','"+args[11]+"');" ; 
            statement = dbConnection.createStatement();
            int rs = statement.executeUpdate(insertTableSQL);
            if (rs==0){
                bandera=true;
            }else
                bandera=false;
        } catch (SQLException e) {
            System.out.println(e.getMessage());            
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return bandera;
    }
    
    /**
     * inserts a new "activo" and returns a confirmation if it was successfull
     * @param args values to insert
     * @return true if successfully inserted, false otherwise
     * @throws SQLException 
     */
    public boolean insertActivo(String args) throws SQLException {
        try {
            Class.forName(DRIVER);
            dbConnection = DriverManager.getConnection(URL_CONEXION, usuario, password);
            String insertTableSQL = "INSERT INTO activo (subestacion) VALUES ('"+args+"');" ; 
            statement = dbConnection.createStatement();
            int rs = statement.executeUpdate(insertTableSQL);
            if (rs==0){
                bandera=true;
            }else
                bandera=false;
        } catch (SQLException e) {
            System.out.println(e.getMessage());            
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return bandera;
    }
    
    /**
     * inserts a payment, modifing the corresponding information and returns a confirmation if it was successfull
     * @param args values to insert
     * @return true if successfully inserted, false otherwise
     * @throws SQLException 
     */
    public boolean insertPago(String[] args) throws SQLException {
        try {
            Class.forName(DRIVER);
            dbConnection = DriverManager.getConnection(URL_CONEXION, usuario, password);
            idpago=Integer.parseInt(getLastPago());
            idpago++;
            String insertTableSQL = "INSERT INTO Pago (id,banco, valor) VALUES ("+idpago+", "+args[0]+", "+args[1]+");\n"+
                                    "INSERT INTO Registra (usuarioId, clienteNumCuenta) VALUES ("+args[2]+", "+args[3]+");\n"+
                                    "INSERT INTO Ingresa (usuarioId, pagoId) VALUES ("+args[2]+"," +idpago+");" ; 
            statement = dbConnection.createStatement();
            int rs = statement.executeUpdate(insertTableSQL);
            if (rs==0){
                bandera=true;
            }else
                bandera=false;
        } catch (SQLException e) {
            System.out.println(e.getMessage());            
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return bandera;
    }
    
}